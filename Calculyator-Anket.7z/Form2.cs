namespace WinFormsApp3
{
    public partial class Form2 : Form
    {
        double resultvalue = 0;
        string operationPerformed;
        bool isoperationPerformed = false;

        public Form2()
        {
            InitializeComponent();
        }



        private void button_click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" || (isoperationPerformed))
            {
                textBox1.Clear();

            }
            isoperationPerformed = false;
            Button button = (Button)sender;
            if (button.Text == "0")
            {
                if (!textBox1.Text.Contains("."))
                {
                    textBox1.Text += button.Text;
                }
            }
            else
            {
                textBox1.Text += button.Text;
            }

        }

        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            operationPerformed = button.Text;
            resultvalue = Double.Parse(textBox1.Text);
            label.Text = resultvalue + " " + operationPerformed;
            isoperationPerformed = true;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (operationPerformed == "+")
            {
                textBox1.Text = (resultvalue + double.Parse(textBox1.Text)).ToString();
            }
            else if (operationPerformed == "-")
            {
                textBox1.Text = (resultvalue - double.Parse(textBox1.Text)).ToString();

            }
            else if (operationPerformed == "X")
            {
                textBox1.Text = (resultvalue * double.Parse(textBox1.Text)).ToString();

            }
            else if (operationPerformed == "/")
            {
                textBox1.Text = (resultvalue / double.Parse(textBox1.Text)).ToString();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            label.Text = "0";
            textBox1.Text = "0";
        }
    }
}